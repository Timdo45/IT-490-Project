<?php
session_start();
require('/home/test/IT490/RabbitMQClientSample.php');

if(isset($_POST['submitButton'])){
    try{
        $Username = $_POST['username'];
        $Password = $_POST['password'];
        if($Username != "" && $Password != "" ){
            $rabbitResponse = loginMessage($Username, $Password);
            if($rabbitResponse == false){
                echo "login has failed, please try again";
                //redirect back to login page to try again
            }else{
                echo "You are logged in!";
            }
        }
        else{
            echo "username and password is empty";
        }
    }
    catch(Exception $e){
        echo $e->getMessage();
    }
}

if(isset($_POST['submitButton'])){
    $Username = $_POST['username'];
    $Password = $_POST['password'];

    if ($Username != "" && $Password != ""){
        $rabbitResponse = registerMessage($Username, $Password);

        if($rabbitResponse==false){
            echo "account already created";

        }else{

            echo "Account is created";
            header("Location: index.html");

        }
    }else{
        echo "Nothing entered";
    }

}

?>

<!DOCTYPE html>
<head>
    <title>Login</title>
    <link rel="stylesheet"href="style.css">
</head>
<body>
    <div class ="hero">
          <div class="form-box">
              <div class="button-box">
                  <div id = "btn"></div>
                  <button type="button" class ="toggle-btn" onclick="login()">Log In</button>
                  <button type="button" class ="toggle-btn" onclick="register()">Register</button>
              </div>
              <div class="social-icons">
                <img src="fb.png">
                <img src="tw.png">
                <img src="gp.png">
              </div>
              <form action="#" method="post" id="login" class="input-group">
                  <input type="text" class="input-field" placeholder="Username" name="username" required>
                  <input type="text" class="input-field" placeholder="Enter Password" name="password" required>
                  <input type="checkbox" class="check-box"><span>Remember Password</span>
                  <button type="submit" name="submitButton" class="submit-btn">Log In</button>
              </form>

              <form action="#" method="post" id="register" class="input-group">
                  <input type="email" class="input-field" placeholder="Username" name="username" required>
                  <input type="text" class="input-field" placeholder="Create Password" name="password" required>
                  <input type="checkbox" class="check-box"><span>I agree to the terms &
                  conditions</span>
                  <button type="submit" name="submitButton" class="submit-btn" >Register</button>
              </form>
          </div>

      </div>

      <script>
        var x = document.getElementById("login");
        var y = document.getElementById("register");
        var z = document.getElementById("btn");

        function register() {
              x.style.left = "-400px";
              y.style.left = "50px";
              z.style.left = "110px";
        }
        function login() {
              x.style.left = "50px";
              y.style.left = "450px";
              z.style.left = "0";
        }
      </script>

</body>
</html>
