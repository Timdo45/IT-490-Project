<?php
header("location: login-register.php");
?>
