<?php
session_start();
require('/home/test/IT490/RabbitMQClientSample.php');

if(isset($_POST['submitButton'])){
    try{
        $Username = $_POST['username'];
        $Password = $_POST['password'];
        if($Username != "" && $Password != "" ){
            $rabbitResponse = loginMessage($Username, $Password);
            if($rabbitResponse == false){
                echo "login has failed, please try again";
                //redirect back to login page to try again
            }else{
                echo "You are logged in!";
            }
        }
        else{
            echo "username and password is empty";
        }
    }
    catch(Exception $e){
        echo $e->getMessage();
    }
}
?>
