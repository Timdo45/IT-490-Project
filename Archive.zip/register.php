<?php
require('/home/test/IT490/RabbitMQClientSample.php');
if(isset($_POST['submitButton'])){
    $Username = $_POST['username'];
    $Password = $_POST['password'];

    if ($Username != "" && $Password != ""){
        $rabbitResponse = registerMessage($Username, $Password);

        if($rabbitResponse==false){
            echo "account already created";

        }else{

            echo "Account is created";
            header("Location: index.html");

        }
    }else{
        echo "Nothing entered";
    }

}
